---
layout: default
title: "Core Abstraction"
nav_order: 2
has_children: true
---